from dataProcessor import dataProcessor
import logging as log
from trainerRun import trainerRun


class workerEngine(object):

	def __init__(self, tf_session, tf_inc_op, kafka_message, x,x_assign_op, y_true,y_assign_op,
				 keep_prob,keep_porb_assign_op,writer_train,
				 writer_test,tf_global_step,accuracy,loss,optimizer,learning_rate,merged,y_pred_cls,log_dir,epoches):
		self.tf_session = tf_session
		self.inc_op = tf_inc_op
		self.work_message = kafka_message
		self.input_x = x
		self.input_y = y_true
		self.keep_prob = keep_prob
		self.aws_file = None
		self.aws_bucket = None
		self.data_processor = None
		self.epoch = epoches
		self.batch_size = 128
		self.test_file = None
		self.writer_train = writer_train
		self.writer_test = writer_test
		self.train_runner = None
		self.tf_global_step = tf_global_step
		self.test_data = None
		self.x_assign_op = x_assign_op
		self.y_assign_op = y_assign_op
		self.keep_prob_assign_op = keep_porb_assign_op
		self.accuracy = accuracy
		self.loss = loss
		self.merged = merged
		self.learning_rate = learning_rate
		self.log_dir = log_dir
		self.optimizer = optimizer
		self.y_pred_cls = y_pred_cls


	def read_kafka_message(self):
		self.aws_file = self.work_message['file_path']
		self.aws_bucket = self.work_message['aws_bucket']
		self.test_file = self.work_message['test_file']

	def download_and_process_file(self):
		self.data_processor = dataProcessor(self.aws_bucket, self.aws_file)
		self.data_processor.process_data()


	def get_test_data(self):
		test_data_processor = dataProcessor(self.aws_bucket, self.test_file)
		test_data_processor.process_data()
		self.test_data =(test_data_processor.normalized_data,test_data_processor.label_data)

	def start(self):
		try:

			self.read_kafka_message()
			self.download_and_process_file()
			train_runner = trainerRun(self.tf_session, self.input_x, self.x_assign_op, self.input_y,
									  self.y_assign_op,
									  self.keep_prob, self.keep_prob_assign_op,
									  self.writer_train, self.writer_test, self.tf_global_step,self.accuracy,self.loss
									  ,self.optimizer,self.learning_rate,self.merged)
			for j in range(self.epoch):
				train_runner.train_run(self.data_processor,j)
			# train_runner.test_run(self.test_data)
			log.info("======> completed training on the kafka message incrementing the counter")
			self.tf_session.run(self.inc_op)
		except Exception as E:
			log.error("------> unable to train failed with exception %s" %format(E))