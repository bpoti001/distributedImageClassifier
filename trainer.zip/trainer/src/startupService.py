from config_parse import get_config,set_config
import logging as log
import logging.config
import os
import holder
from Connectors import kafkaProducerService
from monitoring import monitoring_push


def main(is_chief,context):
    # set logging
    config_file = os.path.join(os.path.dirname(__file__), 'logging.ini')
    log.config.fileConfig(config_file)
    log.info("---> Reading local config file")
    if context.get("LOG_LEVEL"):
        logger = log.getLogger()
        logger.setLevel(context.get("LOG_LEVEL"))
        log.info(" ----> logging level set to %s ",context.get("LOG_LEVEL"))
    host_name = os.getenv('MESOS_CONTAINER_IP')
    gateway_url = context.get("MONITORING_URL")
    app_id = context.get("APPLICATION_ID")
    host_name = host_name
    log.info("----> monitoring app name %s", app_id)
    log.info("---> gateway url is %s", gateway_url)
    monitoring_push.main(gateway_url, app_id, {"job": app_id, "instance": host_name}, 2)
    log.info("----> Started monitoring stats to push ")
    log.info(os.getenv('FRAMEWORK_HOST'))
    log.info(os.getenv("MESOS_CONTAINER_IP"))
    log.info("---> setting up AWS environment ")
    os.environ["AWS_ACCESS_KEY_ID"]=context.get("AWS_ACCESS_KEY_ID")
    os.environ["AWS_SECRET_ACCESS_KEY"]=context.get("AWS_SECRET_ACCESS_KEY")
    os.environ['AWS_REGION']=context.get("AWS_REGION")
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
    os.environ['S3_REQUEST_TIMEOUT_MSEC']='1500000'


    config = get_config()

    aws_access = context.get("AWS_ACCESS_KEY_ID")
    aws_secret = context.get("AWS_SECRET_ACCESS_KEY")


    log.info("---> Set up kafka configs")

    config.set('KAFKA','KAFKA_BOOTSTRAP_SERVERS',context.get('KAFKA_BROKER'))
    holder.set_s3_connector(aws_access, aws_secret)
    if is_chief:

        # setup producer and consumer for coordinator
        kafka_consumer_topic = context.get('PREFIX')+config.get('KAFKA','KAFKA_CONSUMER_CHIEF_TOPIC')
        config.set('KAFKA','KAFKA_CONSUMER_CHIEF_TOPIC',kafka_consumer_topic)
        kafka_consumer_group = context.get('PREFIX')+config.get('KAFKA','KAFKA_CONSUMER_CHIEF_GROUP')
        config.set('KAFKA','KAFKA_CONSUMER_CHIEF_GROUP',kafka_consumer_group)
        kafka_producer_topic = context.get('PREFIX')+config.get('KAFKA','KAFKA_PRODUCER_CHIEF_TOPIC')
        config.set('KAFKA','KAFKA_PRODUCER_CHIEF_TOPIC',kafka_producer_topic)
        kafkaProducerService.main([config.get("KAFKA","KAFKA_BOOTSTRAP_SERVERS")])
    else:
        kafka_consumer_worker_topic = context.get('PREFIX')+config.get('KAFKA','KAFKA_CONSUMER_WORKER_TOPIC')
        config.set('KAFKA','KAFKA_CONSUMER_WORKER_TOPIC',kafka_consumer_worker_topic)
        kafka_consumer_worker_group = context.get("PREFIX")+config.get("KAFKA","KAFKA_CONSUMER_WORKER_GROUP")
        config.set("KAFKA","KAFKA_CONSUMER_WORKER_GROUP",kafka_consumer_worker_group)
    config.set('MESOS','APPLICATION_ID',context.get('MESOS_ID'))
    host_name = os.getenv("MESOS_CONTAINER_IP")
    proxy_url = 'http://'+host_name+':'+config.get('API_END_POINT','PROXY_PORT')
    log.info("---> proxy url %s",proxy_url)
    # we use ths dictionary to communicate with outside world via linkered port.
    proxiDict = {config.get('API_END_POINT','PROXY_PROTOCOL'):proxy_url}


    # setup fml_sessions in workers only

    holder.set_porxy(proxiDict)
    # setup fml store object and http client
    log.info("---------> Setup all the required objects in holder")
    #
    # write configs to local files
    log.info("---> writing configs to local file")
    set_config(config)
    holder.set_configuration()
