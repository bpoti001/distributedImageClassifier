from config_parse import get_config
import boto3

from Connectors.s3Utils import S3_connect
s3_connect_object = None
chief_info = False
missing_value = -99999
proxy = None
kafka_consumer = None
config = None
S3 = None
session_pool = None
kafka_producer = None


def set_s3_connector(aws_access,aws_secret):
    global s3_connect_object
    s3_connect_object = S3_connect(aws_access,aws_secret)


def get_s3_connector():
    return s3_connect_object


def set_chief():
    global chief_info
    chief_info = True


def set_porxy(proxiDict):
    global proxy
    proxy = proxiDict


def get_proxy():
    return proxy


def get_chief_info():
    return chief_info


def set_kafka_consumer(consumer):
    global kafka_consumer
    kafka_consumer = consumer


def get_kafka_consumer():
    return kafka_consumer


def set_kafka_producer(producer):
    global kafka_producer
    kafka_producer = producer


def get_kafka_producer():
    return kafka_producer


def set_configuration():
    global config
    config = get_config()


def get_configuration():
    global config
    return config

