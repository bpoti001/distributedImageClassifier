import holder
import logging as log
import json
import tensorflow as tf
from dataProcessor import dataProcessor
from trainerRun import  trainerRun
import time


class chiefEngine(object):
	def __init__(self,aws_bucket,aws_location,tf_global_step,writer_test,
				 writer_train,global_session,counter,
				 x,x_assign,
				 y,y_assign,
				 keep_prob,keep_prob_assign,
				 accuracy, loss, optimizer, learning_rate, merged,y_pred_cls,
				 log_dir,epoches):
		self.aws_bucket = aws_bucket
		self.aws_location = aws_location
		self.tf_global_step = tf_global_step

		self.s3_connector = holder.get_s3_connector()
		self.tf_writer_test = writer_test
		self.tf_writer_train = writer_train
		self.tf_session = global_session
		self.kafka_producer = holder.get_kafka_producer()
		self.tf_counter = counter
		self.accuracy = accuracy
		self.loss = loss
		self.optimizer = optimizer
		self.learning_rate = learning_rate
		self.merged = merged
		self.x = x
		self.y = y
		self.y_pred = y_pred_cls
		self.keep_prob = keep_prob
		self.model_path = "s3://"+aws_bucket+"/model/"
		self.chief_training_data_path= None
		self.check_point_dir = log_dir
		self.x_assign = x_assign
		self.y_assign = y_assign
		self.keep_prob_assign = keep_prob_assign

		self.epochs = epoches
		self.train_batch_size = 128
		self.test_batch_size = 256
		self.wait_counter = 0

	# def write_summaries(self,train):
	# 	status = self.tf_session.run(self.summaries)
	# 	if train:
	# 		self.tf_writer_train.add_summaries(status,global_step=tf.train.global_step(self.tf_session,self.tf_global_step))
	# 	else:
	# 		self.tf_writer_test.add_summaries(status,global_step=tf.train.global_step(self.tf_session,self.tf_global_step))

	def savemodel(self):
		latest_checkpoint = tf.train.latest_checkpoint(self.check_point_dir)
		log.info("-----> checkpoint location is %s" %(str(latest_checkpoint)))
		saver = tf.train.import_meta_graph(latest_checkpoint + ".meta", clear_devices=True)
		with tf.Session() as local_sess:
			saver.restore(local_sess, latest_checkpoint)
			saver.save(local_sess,self.model_path)
			log.info("-----<MODEL SAVED>")

	def get_data(self,file_path):
		data_processor = dataProcessor(self.aws_bucket, file_path)
		data_processor.process_data()
		return data_processor

	def start(self):
		try:
			config = holder.get_configuration()
			log.info("----> scanning for the batched data files")
			files = self.s3_connector.scan_s3_location(self.aws_bucket,self.aws_location)
			files_path = files
			log.info("found the data file paths as %s" %(str(files_path)))
			log.info("-----> distributing the training files to workers to train")
			training_file_path = []
			test_file_path = []
			for i in files_path:
				if "data_batch" in i:
					training_file_path.append(i)
				elif not i.endswith("/"):
					test_file_path.append(i)
				else:
					log.info("----> root location %s" %(str(i)))

			log.info("------> sending files to workers topic")
			log.debug("training batch files %s" %(str(training_file_path)))
			log.debug("------> test file path %s" %(str(test_file_path[0])))
			chief_training_data_path = training_file_path.pop()
			log.debug("-------> chief training path is %s" %(str(chief_training_data_path)))
			for i in training_file_path:
				mes = {"file_path":i,"aws_bucket":self.aws_bucket,"test_file":test_file_path[0]}
				log.debug("-----> message set to %s" %(str(mes)))
				log.debug("----> sending mesasges to %s" %( str(config.get("KAFKA","KAFKA_PRODUCER_CHIEF_TOPIC"))))
				encoded_mess = json.dumps(mes).encode()
				self.kafka_producer.send(config.get("KAFKA","KAFKA_PRODUCER_CHIEF_TOPIC"),encoded_mess).get(timeout=4)

			log.info("----> waiting on workers to complete work")
			train_data_processor = self.get_data(chief_training_data_path)
			test_data_processor = self.get_data(test_file_path[0])
			train_runner = trainerRun(self.tf_session, self.x,self.x_assign, self.y,self.y_assign,
									  self.keep_prob,self.keep_prob_assign,
									  self.tf_writer_train, self.tf_writer_test, self.tf_global_step,self.accuracy,self.loss,
									  self.optimizer,self.learning_rate,self.merged,y_pred=self.y_pred,test_data_processor = test_data_processor)
			flag = True
			train_flag = True
			log.info("-------> starting loop")
			while flag:
				counter = self.tf_counter.eval(session=self.tf_session)
				log.info("counter value %s" %(str(counter)))
				# global_step = tf.train.global_step(self.tf_session, self.tf_global_step)
				if counter == len(training_file_path):
					flag = False
					log.info("---> workers completed the work writer summaries")
				elif train_flag:
					log.info("-------> starting the training loop")
					for j in range(self.epochs):
						log.info("00000000>> epoch %s " %(str(j)))
						train_runner.train_run(train_data_processor,j)
					train_flag = False
				else:
					log.info("----> waiting on workers and writing summaries")
					self.wait_counter = self.wait_counter+1

					if self.wait_counter%200 == 0:
						train_runner.test_and_write(self.epochs)
						time.sleep(5)
			self.savemodel()
			log.info("----> Model saved successfully")

		except Exception as e:
			log.error("-----> unable to process the message failed with error %s" % format(e))
			log.exception(e)






