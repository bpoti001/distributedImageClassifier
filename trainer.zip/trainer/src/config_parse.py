import configparser
import os
configfile_name = os.path.join(os.path.dirname(__file__), 'config.ini')


# read configfile and returns config
def get_config():
    config = configparser.ConfigParser()
    config.read(configfile_name)
    return config


# get new config info and update config.ini
def set_config(config):
    with open(configfile_name,'w') as f:
        config.write(f)


if __name__ == "__main__":
    config = get_config()
    print(config.get('KAFKA', 'KAFKA_CONSUMER_CHIEF_TOPIC'))