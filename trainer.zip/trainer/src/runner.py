from config_parse import get_config

from Connectors import kafkaConsumerService
import logging as log
import time
import json
import datetime
import tensorflow as tf
import holder
import startupService
import numpy as np
import multiprocessing as mp
from model.VGG16 import model
from chiefEngine import chiefEngine
from workerEngine import workerEngine


def main(server, log_dir, context):
	tf.logging.set_verbosity(tf.logging.INFO)
	is_chief = server.server_def.task_index == 0  # set variable is_chief to True or False
	if is_chief:
		holder.set_chief()
	startupService.main(is_chief, context)
	# session_dir = log_dir+'checkpoint'

	with tf.device(tf.train.replica_device_setter(
			worker_device="/job:worker/task:%d" %
						  server.server_def.task_index,
			cluster=server.server_def.cluster)):
		x, y, output, y_pred_cls, global_step, learning_rate = model()
		counter = tf.Variable(0, name="counter")
		inc = tf.assign_add(counter, 1, name="increment")
		x_variable = tf.Variable(tf.zeros([10,32,32,3]),name="x_variable")
		x_assign_op = tf.assign(x_variable,x,validate_shape=False,name="x_assign_op")

		y_true_variable = tf.Variable(tf.zeros([10,10]),name="y_true_variable")
		y_true_assign = tf.assign(y_true_variable,y,validate_shape=False,name="y_true_assign")

		keep_prob = tf.placeholder_with_default(0.0,name="keep_prob_holder",shape=None)
		keep_prob_variable = tf.Variable(0.0,name="keep_prob_variable")
		keep_prob_assign = tf.assign(keep_prob_variable,keep_prob,validate_shape=False,name="keep_prob_assign")

		# LOSS AND OPTIMIZER
		loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=output, labels=y))
		optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate,
										   beta1=0.9,
										   beta2=0.999,
										   epsilon=1e-08).minimize(loss, global_step=global_step)

		# PREDICTION AND ACCURACY CALCULATION
		correct_prediction = tf.equal(y_pred_cls, tf.argmax(y, axis=1))
		accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

		# SAVER
		merged = tf.summary.merge_all()
		init_op = tf.global_variables_initializer()

	config = holder.get_configuration()

	# chief/master work
	# create the instances for cassandra query
	def on_message_receive_chief(messages, kwargs):
		global_sess = kwargs['session']
		log_base_location = kwargs['log_dir']
		epoches = kwargs['epoches']

		try:
			Kafka_message = messages[0]
			message = Kafka_message.value
			j_data = json.loads(message.decode())
			aws_location = j_data['aws_location']
			aws_bucket = j_data['aws_bucket']

			today_date = datetime.datetime.today().strftime('%Y/%m/%d')
			writer_location_test = log_base_location + "/logs/ta_classifer/test/" + today_date
			writer_location_train = log_base_location + "/logs/ta_classifer/train/" + today_date
			log.info("----> writer set to %s" % writer_location_test)
			log.info("----> writer set to %s" % writer_location_train)
			writer_train = tf.summary.FileWriter(writer_location_train,global_sess.graph)
			writer_test = tf.summary.FileWriter(writer_location_test,global_sess.graph)
			log.info("---> calling init ")
			global_sess.run(init_op)
			log.info("----> calling chief")
			chief_engine = chiefEngine(aws_bucket, aws_location, global_step,
									   writer_test, writer_train,
									   global_sess, counter, x,x_assign_op,
									   y,y_true_assign, keep_prob,keep_prob_assign,
									   accuracy,loss,optimizer,learning_rate,merged,y_pred_cls,log_dir,epoches)
			chief_engine.start()

			time.sleep(5)
			log.info("workers completed processing messages read to take new message from scheduler")
			global_step_val = tf.train.global_step(global_sess, global_step)
			if global_step_val != 0:
				# forcing global_step_value to set 0
				global_sess.run(init_op)
				global_step_val = tf.train.global_step(global_sess, global_step)
				log.info("current value of global step is %d " % global_step_val)

		except Exception as E:
			log.error("-----> unable to process message")
			log.error(E)
			global_sess.run(init_op)
			raise E

	def on_message_receive_worker(messages, kwargs):
		try:
			log.debug("--=----> worker on message call")
			global_session = kwargs['session']
			log_base_location = kwargs['log_dir']
			epoches = kwargs['epoches']
			today_date = datetime.datetime.today().strftime('%Y/%m/%d')
			writer_location_test = log_base_location + "/logs/ta_classifer/test/" + today_date
			writer_location_train = log_base_location + "/logs/ta_classifer/train/" + today_date
			writer_train = tf.summary.FileWriter(writer_location_train)
			writer_test = tf.summary.FileWriter(writer_location_test)
			kafka_message = messages[0]
			message = kafka_message.value
			j_data = json.loads(message.decode())
			log.info("got message %s " % j_data)
			log.info("-------> Starting worker to process data and training ")
			worker_engine = workerEngine(global_session,inc,
										 j_data, x,x_assign_op, y,y_true_assign, keep_prob,keep_prob_assign,
										 writer_train,writer_test,global_step,accuracy,loss,optimizer,learning_rate,merged,y_pred_cls,log_dir,epoches)
			worker_engine.start()
		except Exception as E:
			log.error("---> failed to process work with exception %s" %(format(E)))
			log.exception(E)

	saver_hook = tf.train.CheckpointSaverHook(
		checkpoint_dir=log_dir,
		save_steps=100
	)

	# starting monitoring session to share the state
	with tf.train.MonitoredTrainingSession(master=server.target,
										   is_chief=is_chief,
										   checkpoint_dir = log_dir,
										   save_checkpoint_steps=10
										   ) as mon_sess:
		if is_chief:
			# add  session and writer to pass to consumer thread
			epoch = int(context.get("epoch"))
			kwarg = {"session": mon_sess, "log_dir": log_dir,"epoches":epoch}
			log.info("starting kafka consumer in chief with  %s group id for %s topic" % (
				config.get("KAFKA", "KAFKA_CONSUMER_CHIEF_GROUP"), config.get("KAFKA", "KAFKA_CONSUMER_CHIEF_TOPIC")))
			kafkaConsumerService.main(on_message_receive_chief,
									  config.get('KAFKA', 'KAFKA_CONSUMER_CHIEF_TOPIC'),
									  [config.get("KAFKA", "KAFKA_BOOTSTRAP_SERVERS")],
									  config.get("KAFKA", "KAFKA_AUTO_OFFSET_RESET"),
									  1, group_id=config.get("KAFKA", "KAFKA_CONSUMER_CHIEF_GROUP"),
									  kvargs=kwarg, num_records_to_poll=1)
			# Keeping chief MainThread Alive
			while True:
				pass

		if not is_chief:
			# number_messages = int(context.get("MAX_PROCESSORS"))
			# add session to pass to consumer thread.
			epoch = int(context.get("epoch"))
			kwarg = {'session': mon_sess,"log_dir": log_dir,"epoches":epoch}
			log.info("starting kafka consumer in worker with  %s group id for %s topic" % (
				config.get("KAFKA", "KAFKA_CONSUMER_WORKER_GROUP"), config.get("KAFKA", "KAFKA_CONSUMER_WORKER_GROUP")))
			kafkaConsumerService.main(on_message_receive_worker,
									  config.get('KAFKA', 'KAFKA_CONSUMER_WORKER_TOPIC'),
									  [config.get("KAFKA", "KAFKA_BOOTSTRAP_SERVERS")],
									  config.get("KAFKA", "KAFKA_AUTO_OFFSET_RESET"),
									  1, group_id=config.get("KAFKA", "KAFKA_CONSUMER_WORKER_GROUP"),
									  kvargs=kwarg, num_records_to_poll=1)
			# keeping workers MainThread Alive
			while True:
				pass
