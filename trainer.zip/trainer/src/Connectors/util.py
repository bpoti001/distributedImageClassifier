from kafka import TopicPartition
import json

def get_topic_partition(topic,partition_id):
    return TopicPartition(topic,partition_id)


class KafkaMessage:
    def __init__(self):
        self.job_id = None
        self.value = None
    def set_value(self):
        message = {"jobId": self.job_id,"status": "Running"}
        self.value = json.dumps(message).encode()


