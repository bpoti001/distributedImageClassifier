import time
from Connectors.kafkaProducer import Producer
import logging as log

def main(bootstrap_server):
    threads = [
        Producer(bootstrap_server)
    ]

    for t in threads:
        log.debug("----> starting producer thread: " + str(t.getName()))
        t.start()
        log.debug("----> the following producer thread has been started: " + str(t.getName()))

    time.sleep(2)