import logging as log
import time
from kafka import KafkaProducer
import sys
from Connectors.kafkaConsumer import Consumer
import types


def main(inject_function, KAFKA_CONSUMER_TOPIC, KAFKA_BOOTSTRAP_SERVERS, offset_reset,
         consumer_number,group_id=None,dlq_topic=None,kvargs=None,num_records_to_poll=1):
    """

    :param inject_function: Method to be executed upon receiving records from kafka consumer : <class 'function'>
    :param KAFKA_CONSUMER_TOPIC: which topic to be consumed : String
    :param KAFKA_BOOTSTRAP_SERVERS: Array of servers for Active Active Kafka :array of strings
    :param offset_reset: From where to start to received messages : {earliest/latest}
    :param consumer_number: number of consumer threads to start : int
    :param group_id: consumer group name : string .default None
    :param dlq_topic: Dead letter queue to send messages which are not able to be processed : string . default None
    :param kvargs: dictionary of key value arguments need to be passed while calling inject_function: Dict .Default None
    :param num_records_to_poll: Number of records to be consumed in one poll : int default 1
    :return:
    """
    if isinstance(inject_function, types.FunctionType):
        pass
    else:
        log.error("---> inject_function or first argument needs to be a function which needs to be executed upon message receive")
        raise TypeError("inject_function or first argument needs to be a function which needs to be executed upon message receive")
    if type(KAFKA_BOOTSTRAP_SERVERS) != list:
        log.error("------> KAFKA_BOOTSTRAP_SERVERS should be a list of Kafka brokers")
        raise TypeError("KAFKA_BOOTSTRAP_SERVERS should be a list of Kafka brokers")
    threads = []
    counter = 0
    if dlq_topic:
        fallback_producers = []
        for boot_strap_server in KAFKA_BOOTSTRAP_SERVERS:
            fallback_producers.append(KafkaProducer(bootstrap_servers=boot_strap_server))
    else:
        fallback_producers = []
        for boot_strap_server in KAFKA_BOOTSTRAP_SERVERS:
            fallback_producers.append('None')
    for i in range(consumer_number):
        for boot_strap_server,dlq_producer in zip(KAFKA_BOOTSTRAP_SERVERS,fallback_producers):
            counter = counter+1
            consumer_obj = Consumer(inject_function, KAFKA_CONSUMER_TOPIC,boot_strap_server,
                                    offset_reset,dlq_topic,group_id,dlq_producer,kvargs,num_records_to_poll)
            consumer_obj.setName("Kafka_consumer:"+str(counter))
            threads.append(consumer_obj)

    for t in threads:
        try:
            log.info("----> starting consumer thread: " + str(t.getName()))
            t.start()
            log.info("----> the following consumer thread has been started: " + str(t.getName()))
        except:
            log.error("------> Error starting consumer threads".format(sys.exc_info()[0]))
            raise

    time.sleep(2)
