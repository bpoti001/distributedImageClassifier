import logging as log
import boto3
from datetime import datetime
import json
from botocore.exceptions import ClientError

class S3_connect:
    def __init__(self,aws_access,aws_secret):
        self.aws_access = aws_access
        self.aws_secret = aws_secret
        self.S3 = None
        self.__create_s3_session()


    def __create_s3_session(self):
        self.session = boto3.Session(
            aws_access_key_id=self.aws_access,
            aws_secret_access_key=self.aws_secret,
        )
        self.S3 = self.session.resource('s3')

    def download_file(self,aws_bucket,aws_location):
        """

        :param aws_bucket: bucket name
        :param aws_location: file name to be downloaded
        :return: file contents
        """
        for i in range(3):
            try:
                log.info("----> download from location %s" %aws_location)
                get_obj=self.S3.Object(aws_bucket,aws_location)
                response = get_obj.get()
                content_obj = response['Body']
                file_content = content_obj.read()
                return file_content
            except ClientError as ex:
                if ex.response['Error']['Code'] == 'NoSuchKey':
                    log.error("----> aws key not found ")
                    return None
            except Exception as E:
                if i !=2:
                    log.error("----> Exception from S3 while download on trail %d in retry loop" % i)
                    log.error("----> %s" % E)
                else:
                    log.error("---> Tried 3 times to download file from S3, failed with Exception")
                    log.exception(E)
                    raise E
    def scan_s3_location(self,aws_bucket,aws_location):
        """
        :param aws_bucket: aws bucket
        :param aws_location: location from root folder
        :return: generator for the files
        """
        bucket = self.S3.Bucket(aws_bucket)
        gene = (_.key for _ in bucket.objects.filter(Prefix=aws_location))
        try:
            d = [ i for i in gene if aws_location+"/" in i]
            return d
        except ClientError as e:
           if e.response['Error']['Code'] == 'NoSuchBucket':
                log.error("-----> BucketName not found")
                raise e
        except Exception as e:
            log.error("-----> Failed to scan location with error %s" %format(e))
            log.exception(e)
            raise e

    def upload_file(self,aws_bucket,aws_location,serialized_data):
        '''

        :param aws_bucket: aws bucket to upload file
        :param aws_location: key name in aws to upload the contents
        :param serialized_data: contents in serialized mode
        :return:
        '''
        for i in range(3):
            try:
                log.info("----> trying to upload in location %s" % aws_location)
                put_obj=self.S3.Object(aws_bucket,aws_location)
                put_obj.put(Body=serialized_data)
                break
            except Exception as E:
                if i !=2:
                    log.error("----> Exception from S3 on trail %d in retry loop" % i)
                    log.error("----> %s" % E)
                else:
                    log.error("---> Tried 3 times to put model to S3 failed with Exception")
                    log.exception(E)
                    raise E


if __name__=="__main__":
    s3_ob = S3_connect("AKIAIF2UPUP3VCPEWR4Q","ItgRmHU6XTDUMfCcQ0UZhl+WmBhgGFnbNI04cfWk")