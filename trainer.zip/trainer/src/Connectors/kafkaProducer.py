import threading
from kafka import KafkaProducer
import holder
import logging as log


class Producer(threading.Thread):
    def __init__(self,bootstrap_server):
        threading.Thread.__init__(self)
        self.daemon = True
        self.bootstrap = bootstrap_server

    def run(self):
        producer = KafkaProducer(bootstrap_servers=self.bootstrap)
        log.info("-----> setting kafka producer with bootstrap %s" %(str
                                                                     (self.bootstrap)))
        holder.set_kafka_producer(producer)
        log.info("---> setup holder")