import json
import logging as log
import sys
import time
import threading
from kafka import KafkaConsumer
from kafka import KafkaProducer
import holder
from Connectors.util import KafkaMessage
from kafka.structs import OffsetAndMetadata


class Consumer(threading.Thread):
    def __init__(self, inject_function, topic, broker, offset, dlq_topic_name=None,
                 group_id=None,dlq_producer=None,kvargs=None,num_records_to_poll=1):
        threading.Thread.__init__(self)
        self.daemon = True
        self.execution_function = inject_function
        self.topic = topic
        self.broker = broker
        self.offset = offset
        self.dlq_topic = dlq_topic_name
        self.group_id = group_id
        self.dlq_producer = dlq_producer
        self.kvargs = kvargs
        self.num_records_to_poll = num_records_to_poll
        self.consumer = None
        self.dummy_message = KafkaMessage()

    def __method_exection(self, messages):
        """
        :param messages:  array of messages to be processed
        :return:True/ failed message
        On_message_receive method of application will be called
        from here which will process the batch of messages.

        Add retry logic in the application level. If all messages are able to
        process, return True

        """
        for retry in range(3):
            try:
                log.debug("---> calling injection function")
                if self.kvargs:
                    self.execution_function(messages,self.kvargs)
                else:
                    self.execution_function(messages)
                break
            except Exception as E:
                log.debug("chief info %s" %(str(holder.get_chief_info())))
                if not holder.get_chief_info():
                    for message in messages:
                        self.produce_dlq(message)
                    break
                log.error("--->Failed to process messages with Exception %s" %(format(E)))
                if retry ==2:
                    for message in messages:
                        self.produce_dlq(message)

    def produce_dlq(self, message):
        """
        :param message:
        :return:
        messages those are not able to be processed will be
        send to Dead Letter Queue
        """
        if self.dlq_topic:
            try:
                feature = self.dlq_producer.send(self.dlq_topic, message.value)
                feature.get(1)
                log.info("---> Send message to DLQ topic %s " % self.dlq_topic)
                log.info("---> Send message %s " % message.value)
            except Exception as ex:
                log.error("---> error setting up and sending message to DLQ topic %s" % (format(ex)))
        else:
            log.info("---> No DLQ topic provided to send error message")

    def run(self):
        """
        :return:

        Overrides thread-run, till will be invoked upon thread.start()
        we setup kafka consumer and will poll for requested number of messages.
        We pause those topics from which we received  records
        Upon completion of message execution we resume and commit the offsets and poll again.
        """

        try:
            log.info("---> start kafka consumer for topic  %s",self.topic)
            log.info("----> starting kafka consumer for broker %s",self.broker)
            self.consumer = KafkaConsumer(bootstrap_servers=self.broker, auto_offset_reset=self.offset,group_id=self.group_id,enable_auto_commit=False)
            holder.set_kafka_consumer(self.consumer)
            self.consumer.subscribe([self.topic])
        except Exception as ex:
            log.error("----> Error setting up kafka consumer %s" %(format(ex)))
            raise ex

        self._poll_kafka()

    def _poll_kafka(self):
        while True:
            records = self.consumer.poll(max_records=self.num_records_to_poll)
            if not records:
                log.debug("-------> polling records")
                time.sleep(2)
                pass
            else:
                log.info("---- > got message from kafka ")
                batch_records =[]
                # records is a dictionary of {topic_partition:[record,record,record],
                # topic_partition2:[record,record,record]}
                log.debug("chief info %s" % (str(holder.get_chief_info())))
                for topic_partition in records.keys():
                    for record in records[topic_partition]:
                        self.consumer.commit({topic_partition:OffsetAndMetadata(record.offset+1, None)})
                        batch_records.append(record)
                        self.consumer.pause(topic_partition)
                log.info("-----> calling execution message")
                self.__method_exection(batch_records)
                log.info("----> batch processing of records completed. ")
                try:
                    log.info("-----> trying to resume partitions")
                    for topic_partition in records.keys():
                        self.consumer.resume(topic_partition)
                    log.info("----> going to consume new messages from Kafka")
                    '''
                    else:
                        log.info("-----> trying to resume partitions and commit")
                        for tp in records.keys():
                            for record in records[tp]:
                                self.consumer.commit({tp:OffsetAndMetadata(record.offset+1, None)})
                                log.debug("----> commit Offsets to Kafka")
                                '''
                except Exception as E:
                    log.info("got error while trying to resume and commit %s" % (format(E)))
                    log.info("---> going to consume new message from topic")

