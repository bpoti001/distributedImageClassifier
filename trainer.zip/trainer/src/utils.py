import logging as log
from functools import wraps


def retry(fun):
    @wraps(fun)
    def func_wrap(*args,**kwargs):
        for i in range(3):
            try:
                log.info("---> trying  %s function %s time" % (fun.__name__,str(i)))
                re = fun(*args,**kwargs)
                return re
            except Exception as E:
                log.info("----> caught exception %s" %(format(E)))
                log.error(E)
                if i ==2:
                    log.error("=-----> caught exception 3 times while trying to run %s function ending the loop" %(fun.__name__))
                    raise Exception(E)

    return func_wrap
