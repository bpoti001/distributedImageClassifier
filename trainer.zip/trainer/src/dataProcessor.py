import pickle
import logging as log
import holder
import numpy as np
import random
# called by the worker. to download the batch data from s3 and to do transformations.
class dataProcessor(object):
	def __init__(self,aws_bucket,aws_file):
		self.aws_bucket = aws_bucket
		self.file_location = aws_file
		self.normalized_data = None
		self.label_data = None
		self.i = 0
		self.zipped_data = []

	def download_file(self):
		try:
			file_contents = holder.get_s3_connector().download_file(self.aws_bucket,self.file_location)
			if file_contents :
				return file_contents
			else:
				log.info("------> File %s not found in AWS bucket %s " % (self.file_location,self.aws_bucket))
		except Exception as E:
			log.info("-------> Failed to download the file from S3")
			log.exception(E)

	def one_hot_encoding(self,vec,vals = 10):
		'''
		For use to one-hot encode the 10- possible labels
		'''
		n = len(vec)
		out = np.zeros((n, vals))
		out[range(n), vec] = 1
		return out

	def process_data(self):
		try:
			log.info("-----> Downloading files this will take time")
			file_contents = self.download_file()
			if file_contents:
				log.info("----> File download complete ")
				dictData = pickle.loads(file_contents,encoding="bytes")
				labels_one_hot_encoded = self.one_hot_encoding(dictData['labels'.encode()])
				batch_x= dictData['data'.encode()]
				batch_x = np.array(batch_x,dtype=float)/255.0
				batch_x = batch_x.reshape([-1,3,32,32])
				batch_x = batch_x.transpose([0,2,3,1])
				batch_x = batch_x.reshape(-1,32*32*3)
				self.normalized_data = batch_x
				self.label_data = labels_one_hot_encoded
				for x,y in zip(self.normalized_data,self.label_data):
					self.zipped_data.append((x,y))
		except Exception as E:
			log.error("-----> failed to process data with error %s" % format(E))

	def get_batch(self,batch_size):
		if self.i + batch_size < len(self.normalized_data):
			x = self.normalized_data[self.i:self.i + batch_size].reshape(batch_size,32*32*3)
			y = self.label_data[self.i:self.i + batch_size]
		else:
			x = self.normalized_data[self.i:].reshape(-1, 32*32*3)
			y = self.label_data[self.i:]
		self.i = (self.i + batch_size) % len(self.normalized_data)
		return x, y

	def get_random_batch(self,batch_size):
		random.shuffle(self.zipped_data)
		batch = self.zipped_data[0:batch_size]
		x = np.array([x[0] for x in batch])
		y = np.array([x[1] for x in batch])
		return x,y










