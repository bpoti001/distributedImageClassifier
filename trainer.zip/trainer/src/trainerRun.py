import logging as log
import tensorflow as tf
import holder
from time import time
import numpy as np


class trainerRun(object):
	def __init__(self,tf_session,tf_input_x,tf_input_x_assign,tf_input_y,tf_input_y_assign,tf_input_keep_prob,tf_keep_prob_assign,
				 tf_train_writer,tf_test_writer, tf_global_step,accuracy,loss,optimizer,learning_rate,merged,y_pred= None,test_data_processor=None):
		self.tf_session = tf_session
		self.tf_input_x = tf_input_x
		self.tf_input_y = tf_input_y
		self.tf_input_keep_prob = tf_input_keep_prob
		self.train_writer = tf_train_writer
		self.tf_global_step = tf_global_step
		self.counter = 0
		self.test_writer = tf_test_writer
		self.tf_input_x_assign = tf_input_x_assign
		self.tf_input_y_assign = tf_input_y_assign
		self.tf_keep_prob_assign = tf_keep_prob_assign
		self.accuracy = accuracy
		self.loss = loss
		self.optimizer = optimizer
		self.learning_rate = learning_rate
		self.merged = merged
		self.train_batch_size = 128
		self.test_data_processor = test_data_processor
		self.y_pred = y_pred
		self.acc_holder=0

	def train_run(self,data_processor,epoch):
		for i in range(0, len(data_processor.normalized_data), self.train_batch_size):
			self.counter = self.counter+1
			batch = data_processor.get_batch(self.train_batch_size)
			log.info("----> got batch data")
			log.info("------------> running training ")
			start_time = time()
			i_global, _, batch_loss, batch_acc = self.tf_session.run([self.tf_global_step, self.optimizer, self.loss, self.accuracy],
																	 feed_dict={self.tf_input_x: batch[0], self.tf_input_y: batch[1],
																			self.learning_rate: self.lr(epoch)})
			if self.counter % 20 == 0:
				if holder.chief_info:
					log.info("-----> writing loss information")
					summary = tf.Summary(value=[
						tf.Summary.Value(tag="loss/train", simple_value=batch_loss), ])
					self.train_writer.add_summary(summary, i_global)


			duration = time() - start_time
		log.info("----> epoch completed")
		if holder.chief_info:
			log.info("---> testing in chief")
			self.test_and_write(epoch)

	def lr(self,epoch):
		learning_rate = 1e-3
		if epoch > 80:
			learning_rate *= 0.5e-3
		elif epoch > 60:
			learning_rate *= 1e-3
		elif epoch > 40:
			learning_rate *= 1e-2
		elif epoch > 20:
			learning_rate *= 1e-1
		return learning_rate

	def test_and_write(self, epoch):
		i = 0
		predicted_class = np.zeros(shape=len(self.test_data_processor.label_data), dtype=np.int)
		while i < len(self.test_data_processor.normalized_data):
			j = min(i + self.train_batch_size, len(self.test_data_processor.normalized_data))
			batch_xs = self.test_data_processor.normalized_data[i:j, :]
			batch_ys = self.test_data_processor.label_data[i:j, :]
			predicted_class[i:j] = self.tf_session.run(
				self.y_pred,
				feed_dict={self.tf_input_x: batch_xs, self.tf_input_y: batch_ys, self.learning_rate: self.lr(epoch)}
			)
			i = j
		correct = (np.argmax(self.test_data_processor.label_data, axis=1) == predicted_class)
		acc = correct.mean() * 100
		i_global = self.tf_session.run(self.tf_global_step)
		if i_global !=0 and self.acc_holder <acc:
			summary = tf.Summary(value=[
				tf.Summary.Value(tag="Accuracy/test", simple_value=acc), ])
			log.info("-----> calling write summaries ")
			self.train_writer.add_summary(summary, i_global)

