from datetime import datetime
from prometheus_client import Gauge
from functools import wraps
import threading
_function_gauge = Gauge('Application_Custom_metrics','Application Function metrics',['function_name','measure'])


def function_counter(fun):
    @wraps(fun)
    def func_wrap(*args, **kwargs):
        thread_name = threading.current_thread().name
        _function_gauge.labels(thread_name+' '+fun.__name__,'function_counter').inc(1)
        re = fun(*args,**kwargs)
        return re
    return func_wrap


def latency(fun):
    @wraps(fun)
    def func_wrap(*args,**kwargs):
        thread_name = threading.current_thread().name
        start_time = datetime.now()
        re = fun(*args,**kwargs)
        diff = datetime.now()-start_time
        _function_gauge.labels(thread_name+' '+fun.__name__,'time_taken_single_run').set(diff.total_seconds())
        return re
    return func_wrap


def exception_counter(fun):
    @wraps(fun)
    def func_wrap(*args,**kwargs):
        thread_name = threading.current_thread().name
        try:
            re = fun(*args,**kwargs)
            _function_gauge.labels(thread_name+' '+fun.__name__,'success_counter').inc(1)
        except Exception as E:
            re= None
            _function_gauge.labels(thread_name+' '+fun.__name__,'exception_counter').inc(1)
            raise E
        return re
    return func_wrap


