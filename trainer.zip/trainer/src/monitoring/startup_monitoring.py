import logging as log
import sys
from monitoring.default_metric import host_monitoring
from monitoring.http_export import start_custom_http_server



def main(prometheus_port):
    start_custom_http_server(prometheus_port)
    log.debug("----> starting http server to push monitoring metric on port : "+ str(prometheus_port))
    threads = [
        host_monitoring()
    ]
    for t in threads:
        try:
            log.debug("----> starting host_monitoring thread in daemon mode: "+ t.getName())
            t.start()
            log.debug("----> the following monitoring thread has been started: "+ t.getName())
        except:
            log.error("------> Error starting host_monitoring thread".format(sys.exc_info()[0]))


