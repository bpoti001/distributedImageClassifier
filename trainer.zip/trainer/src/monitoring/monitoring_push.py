import logging as log
import sys
from monitoring.default_metric import host_monitoring
from monitoring.pushMetric import PushMetric


def main(gateway_url,app_id,grouping_key,time_interval):

    '''
    :param gateway_url: prometheus gateway url to push metric
    :param app_id:job name to which the metric is connected
    :param time_interval: time interval in seconds to push to gateway
    :param grouping_key : instance id
    :return:
    '''
    if type(time_interval) != int:

        raise TypeError("time_interval must be integer")
    threads = [
        host_monitoring(),
        PushMetric(gateway_url,app_id,grouping_key,time_interval)
    ]
    for t in threads:
        try:
            log.info("----> starting threads for host monitoring and push metric")
            t.start()
            log.info("----> started thread for monitoring")
        except Exception as E:
            log.error("------> Error starting host_monitoring thread %s" %format(E))

