import threading
import logging as log
from http.server import BaseHTTPRequestHandler, HTTPServer
from prometheus_client import generate_latest,core
CONTENT_TYPE_LATEST = str('text/plain; version=0.0.4; charset=utf-8')
class HealthRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', CONTENT_TYPE_LATEST)
        self.end_headers()
        if self.path == "/internal/status":
            self.wfile.write(bytes("{\"status\":true}", "utf8"))
        elif self.path=='/metrics':
            self.wfile.write(generate_latest(core.REGISTRY))
        return

    def log_message(self, format, *args):
        return


def start_custom_http_server(port, addr=''):
    class HealthRequestServer(threading.Thread):
        def run(self):
            httpd = HTTPServer((addr, port), HealthRequestHandler)
            httpd.serve_forever()
    t = HealthRequestServer()
    t.daemon = True
    log.debug("----> starting http service thread in daemon mode: "+ t.getName())
    t.start()
    log.debug("----> the following http service thread has been started: "+ t.getName())