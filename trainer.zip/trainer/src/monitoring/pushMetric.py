import threading
from prometheus_client import CollectorRegistry, push_to_gateway,generate_latest,core
import time
import logging as log


class PushMetric(threading.Thread):
    def __init__(self,gateway_url,app_id,grouping_key,time_interval):
        threading.Thread.__init__(self)
        self.daemon = True
        self.gateway = gateway_url
        self.app_id = app_id
        self.time_interval = time_interval
        self.grouping_key = grouping_key

    def run(self):
        try:
            log.info("-----> starting loop for push metric")
            while True:
                # registry = CollectorRegistry()
                push_to_gateway(self.gateway, job=self.app_id,grouping_key=self.grouping_key, registry=core.REGISTRY)
                time.sleep(self.time_interval)
        except Exception as E:
            log.error("----> unable to start loop for push metric %s" % format(E))

