from prometheus_client import Gauge
import time
import psutil
import threading
import platform
from datetime import datetime



class host_monitoring(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.daemon = True
        self.start_time = datetime.now()
        if platform.system()=='Linux':
            self.flag = True
        else:
            self.flag = False
    def run(self):
        memory_metric = Gauge('memory_usage','memory usage in bytes',['type','status'])
        cpu_metric = Gauge('CPU_usage_Percent','CPU Usage Percent',['Core'])
        application_run_time = Gauge('application_run_time','time in seconds',['gague_info'])
        while True:
            ram = psutil.virtual_memory()
            swap = psutil.swap_memory()
            memory_metric.labels('virtual','total').set(ram.total)
            memory_metric.labels('virtual','available').set(ram.available)
            memory_metric.labels('virtual','used').set(ram.used)
            memory_metric.labels('virtual','free').set(ram.free)
            memory_metric.labels('virtual','active').set(ram.active)
            memory_metric.labels("virtual","inactive").set(ram.inactive)
            if self.flag:
                memory_metric.labels("virtual","buffers").set(ram.buffers)
                memory_metric.labels("virtual","cached").set(ram.cached)
                memory_metric.labels("virtual","shared").set(ram.shared)
            memory_metric.labels("swap","total").set(swap.total)
            memory_metric.labels("swap","used").set(swap.used)
            memory_metric.labels("swap","free").set(swap.free)
            for c,p in enumerate(psutil.cpu_percent(interval=1, percpu=True)):
                cpu_metric.labels(c).set(p)
            diff = datetime.now()-self.start_time
            application_run_time.labels('total application run time').set(diff.total_seconds())
        time.sleep(5)